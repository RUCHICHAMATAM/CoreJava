package com.trainingapps.userms;

import com.trainingapps.companyms.Company;
import com.trainingapps.jobs.*;

public class Main {
    public static void main(String[] args) {

        BaseJobService baseJobService=new ITJobService();
        baseJobService.jobssize(3);
        Company company1=new Company("wipro","wipro pvt limited");
        ITJobs job1=new ITJobs(1234,"coding",company1,"java",4);
        baseJobService.addjobs(job1);
        BaseJobService baseJobService1=new ElectronicJobService();
        ElectronicJobs job2=new ElectronicJobs(12341,"electronic",company1,"oscillator",3);
        baseJobService1.addjobs(job2);
    }
}
